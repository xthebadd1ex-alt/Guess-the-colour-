const grid = document.getElementById("grid");
const generateBtn = document.getElementById("generateBtn");
const doneBtn = document.getElementById("doneBtn");
const replayBtn = document.getElementById("replayBtn");
const clueLabel = document.getElementById("clue");
const dice = document.getElementById("dice");
const realBox = document.getElementById("real");

let cells = [];
let selected = null;
let targetColor = null;
let currentClue = 0;
let cluesForCurrent = [];

// Pool of colours with descriptive clue words
const coloursPool = [
  {color: 'hsl(330,90%,70%)', clues: ["Bubblegum","Hot Pink","Cotton Candy"]},
  {color: 'hsl(120,80%,50%)', clues: ["Frog","Mint","Limeade"]},
  {color: 'hsl(60,90%,60%)', clues: ["Lemon","Sunshine","Banana Peel"]},
  {color: 'hsl(200,85%,55%)', clues: ["Ocean","Skyline","Deep Sea"]},
  {color: 'hsl(0,90%,50%)', clues: ["Cherry","Fireball","Apple"]},
  {color: 'hsl(30,90%,60%)', clues: ["Pumpkin","Rust","Copper"]},
  {color: 'hsl(270,80%,65%)', clues: ["Lavender","Twilight","Grape"]},
  {color: 'hsl(15,85%,60%)', clues: ["Sunset","Coral","Flame"]},
  {color: 'hsl(45,85%,65%)', clues: ["Honey","Banana","Dandelion"]},
  {color: 'hsl(180,70%,55%)', clues: ["Turquoise","River","Teal"]},
  {color: 'hsl(90,80%,50%)', clues: ["Jungle","Grass","Forest"]},
  {color: 'hsl(300,85%,65%)', clues: ["Orchid","Violet","Mystic"]},
  {color: 'hsl(210,90%,55%)', clues: ["Ice","Glacier","Blueberry"]},
  {color: 'hsl(0,30%,50%)', clues: ["Chocolate","Cinnamon","Rust"]},
  {color: 'hsl(330,50%,60%)', clues: ["Magenta","Rose","Hot Cocoa"]},
  {color: 'hsl(200,50%,65%)', clues: ["Sky","Lake","Cerulean"]},
  {color: 'hsl(150,60%,55%)', clues: ["Mint","Aqua","Frost"]},
  {color: 'hsl(30,70%,55%)', clues: ["Maple","Pumpkin Spice","Amber"]}
];

// Generate the colour grid
function makeGrid(){
  for(let y=0; y<18; y++){
    for(let x=0; x<18; x++){
      let hue = (x/18)*360;
      let light = 30 + (y*3);
      let color = `hsl(${hue},80%,${light}%)`;
      let div = document.createElement("div");
      div.className = "cell";
      div.style.background = color;
      div.dataset.color = color;
      div.onclick = () => selectCell(div);
      grid.appendChild(div);
      cells.push(div);
    }
  }
}

// Select a grid cell
function selectCell(cell){
  if(selected) selected.classList.remove("selected");
  selected = cell;
  cell.classList.add("selected");
}

// Dice roll animation before generating
function rollDiceAnimation(callback){
  let rolls = 0;
  const interval = setInterval(()=>{
    dice.textContent = ["🎲","🎯","💥","✨","🌀"][Math.floor(Math.random()*5)];
    rolls++;
    if(rolls>10){
      clearInterval(interval);
      dice.textContent="🎲";
      callback();
    }
  },100);
}

// Generate new colour with 3 clues
generateBtn.onclick = () => {
  rollDiceAnimation(()=>{
    const pick = coloursPool[Math.floor(Math.random()*coloursPool.length)];
    targetColor = pick.color;
    cluesForCurrent = [...pick.clues]; // shuffle clues
    currentClue = 0;
    showNextClue();
    realBox.innerHTML = "";
    realBox.style.display = "none";
    selected = null;
    cells.forEach(c=>c.classList.remove("selected"));
  });
}

// Show next clue in sequence
function showNextClue(){
  if(currentClue < 3){
    clueLabel.textContent = cluesForCurrent[currentClue];
    currentClue++;
  } else {
    if(selected){
      // Create a container to show both colours with labels
      const compareDiv = document.createElement("div");
      compareDiv.style.display = "flex";
      compareDiv.style.justifyContent = "center";
      compareDiv.style.gap = "20px";
      compareDiv.style.marginTop = "10px";

      const yourColorDiv = document.createElement("div");
      yourColorDiv.style.textAlign = "center";
      const yourColor = document.createElement("div");
      yourColor.style.width = "80px";
      yourColor.style.height = "80px";
      yourColor.style.background = selected.dataset.color;
      yourColor.style.border = "3px solid white";
      yourColor.style.borderRadius = "10px";
      yourColor.style.marginBottom = "5px";
      const yourLabel = document.createElement("div");
      yourLabel.textContent = "Your Guess";
      yourColorDiv.appendChild(yourColor);
      yourColorDiv.appendChild(yourLabel);

      const realColorDiv = document.createElement("div");
      realColorDiv.style.textAlign = "center";
      const realColor = document.createElement("div");
      realColor.style.width = "80px";
      realColor.style.height = "80px";
      realColor.style.background = targetColor;
      realColor.style.border = "3px solid white";
      realColor.style.borderRadius = "10px";
      realColor.style.marginBottom = "5px";
      const realLabel = document.createElement("div");
      realLabel.textContent = "Actual Colour";
      realColorDiv.appendChild(realColor);
      realColorDiv.appendChild(realLabel);

      compareDiv.appendChild(yourColorDiv);
      compareDiv.appendChild(realColorDiv);

      realBox.innerHTML = "";
      realBox.appendChild(compareDiv);
      realBox.style.display = "block";
      clueLabel.textContent = "Final Colour Revealed!";
    } else {
      realBox.style.background = targetColor;
      realBox.style.display = "block";
      clueLabel.textContent = "Final Colour Revealed!";
    }
  }
}

// DONE button moves to next clue or reveals colour
doneBtn.onclick = () => {
  if(!targetColor) return;
  showNextClue();
}

// Replay button resets everything
replayBtn.onclick = () => {
  targetColor = null;
  cluesForCurrent = [];
  currentClue = 0;
  selected = null;
  cells.forEach(c=>c.classList.remove("selected"));
  clueLabel.textContent = "Press Generate";
  realBox.style.display = "none";
}

makeGrid();